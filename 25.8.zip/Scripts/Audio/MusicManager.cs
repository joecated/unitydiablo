// MusicManager.cs
using UnityEngine;

// Audio Source bile�eninin bu objede olmas�n� zorunlu k�lar.
[RequireComponent(typeof(AudioSource))]
public class MusicManager : MonoBehaviour
{
    // Inspector'dan atayaca��m�z arka plan m�zi�i
    public AudioClip backgroundMusic;

    private AudioSource audioSource;

    void Start()
    {
        // Audio Source bile�enine eri�
        audioSource = GetComponent<AudioSource>();

        // E�er bir m�zik atanm��sa...
        if (backgroundMusic != null)
        {
            // O m�zi�i �almaya ba�la
            audioSource.clip = backgroundMusic;
            audioSource.Play();
        }
        else
        {
            Debug.LogWarning("MusicManager'a bir arka plan m�zi�i atanmam��!");
        }
    }
}