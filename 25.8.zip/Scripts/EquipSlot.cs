// EquipSlot.cs (YEN� SCRIPT)
public enum EquipSlot { Head, Chest, Legs, Weapon, Shield, Feet }