// DamageType.cs (YEN� SCRIPT)

// Bu bir bile�en (component) olmad��� i�in MonoBehaviour'a ihtiya� duymaz.
// Projedeki herhangi bir yerden eri�ilebilen basit bir veri t�r�d�r.
public enum DamageType { Physical, Magical, True }